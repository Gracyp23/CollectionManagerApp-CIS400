﻿namespace CollectionManagerApp
{
    partial class AddEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDescription = new TextBox();
            txtName = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            textBox1 = new TextBox();
            rdoCorrect = new RadioButton();
            groupBox1 = new GroupBox();
            rdoWrong = new RadioButton();
            checkBox1 = new CheckBox();
            btnSave = new Button();
            btnCancel = new Button();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            lblName = new Label();
            lblDescription = new Label();
            DtpDateAcquired = new Label();
            lblCustomField = new Label();
            groupBox1.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(209, 57);
            txtDescription.Margin = new Padding(3, 2, 3, 2);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(219, 23);
            txtDescription.TabIndex = 3;
            // 
            // txtName
            // 
            txtName.Location = new Point(209, 10);
            txtName.Margin = new Padding(3, 2, 3, 2);
            txtName.Name = "txtName";
            txtName.Size = new Size(219, 23);
            txtName.TabIndex = 1;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(209, 112);
            dateTimePicker1.Margin = new Padding(3, 2, 3, 2);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(219, 23);
            dateTimePicker1.TabIndex = 5;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(209, 170);
            textBox1.Margin = new Padding(3, 2, 3, 2);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(219, 23);
            textBox1.TabIndex = 7;
            // 
            // rdoCorrect
            // 
            rdoCorrect.AutoSize = true;
            rdoCorrect.Location = new Point(5, 29);
            rdoCorrect.Margin = new Padding(3, 2, 3, 2);
            rdoCorrect.Name = "rdoCorrect";
            rdoCorrect.Size = new Size(64, 19);
            rdoCorrect.TabIndex = 0;
            rdoCorrect.TabStop = true;
            rdoCorrect.Text = "Corr&ect";
            rdoCorrect.UseVisualStyleBackColor = true;
            rdoCorrect.CheckedChanged += rdoCorrect_CheckedChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdoWrong);
            groupBox1.Controls.Add(rdoCorrect);
            groupBox1.Location = new Point(10, 208);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(417, 52);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // rdoWrong
            // 
            rdoWrong.AutoSize = true;
            rdoWrong.Location = new Point(310, 29);
            rdoWrong.Margin = new Padding(3, 2, 3, 2);
            rdoWrong.Name = "rdoWrong";
            rdoWrong.Size = new Size(61, 19);
            rdoWrong.TabIndex = 1;
            rdoWrong.TabStop = true;
            rdoWrong.Text = "Wron&g";
            rdoWrong.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(16, 278);
            checkBox1.Margin = new Padding(3, 2, 3, 2);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(90, 19);
            checkBox1.TabIndex = 9;
            checkBox1.Text = "Spe&cial Item";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(415, 276);
            btnSave.Margin = new Padding(3, 2, 3, 2);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(82, 22);
            btnSave.TabIndex = 10;
            btnSave.Text = "Sa&ve";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(528, 278);
            btnCancel.Margin = new Padding(3, 2, 3, 2);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(82, 22);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "&Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1 });
            statusStrip1.Location = new Point(0, 316);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Padding = new Padding(1, 0, 12, 0);
            statusStrip1.Size = new Size(616, 22);
            statusStrip1.TabIndex = 12;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(105, 17);
            toolStripStatusLabel1.Text = "What's Your Status";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(10, 13);
            lblName.Name = "lblName";
            lblName.Size = new Size(39, 15);
            lblName.TabIndex = 0;
            lblName.Text = "&Name";
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.Location = new Point(10, 60);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(67, 15);
            lblDescription.TabIndex = 2;
            lblDescription.Text = "D&escription";
            // 
            // DtpDateAcquired
            // 
            DtpDateAcquired.AutoSize = true;
            DtpDateAcquired.Location = new Point(10, 120);
            DtpDateAcquired.Name = "DtpDateAcquired";
            DtpDateAcquired.Size = new Size(82, 15);
            DtpDateAcquired.TabIndex = 4;
            DtpDateAcquired.Text = "Da&te Acquired";
            // 
            // lblCustomField
            // 
            lblCustomField.AutoSize = true;
            lblCustomField.Location = new Point(10, 173);
            lblCustomField.Name = "lblCustomField";
            lblCustomField.Size = new Size(77, 15);
            lblCustomField.TabIndex = 6;
            lblCustomField.Text = "&Custom Field";
            // 
            // AddEditForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(616, 338);
            Controls.Add(lblCustomField);
            Controls.Add(DtpDateAcquired);
            Controls.Add(lblDescription);
            Controls.Add(lblName);
            Controls.Add(statusStrip1);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(checkBox1);
            Controls.Add(groupBox1);
            Controls.Add(textBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtName);
            Controls.Add(txtDescription);
            Margin = new Padding(3, 2, 3, 2);
            Name = "AddEditForm";
            Text = "Collection Application Item";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDescription;
        private TextBox txtName;
        private DateTimePicker dateTimePicker1;
        private TextBox textBox1;
        private RadioButton rdoCorrect;
        private GroupBox groupBox1;
        private RadioButton rdoWrong;
        private CheckBox checkBox1;
        private Button btnSave;
        private Button btnCancel;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private Label lblName;
        private Label lblDescription;
        private Label DtpDateAcquired;
        private Label lblCustomField;
    }
}