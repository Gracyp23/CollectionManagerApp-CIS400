﻿using System;

namespace CollectionManagerApp
{
    /// <summary>
    /// Represents a book in the collection. Inherits from CollectionItem.
    /// </summary>
    public class Book : CollectionItem
    {
        /// <summary>
        /// The author of the book.
        /// </summary>
        public string Author { get; set; }

        /// <summary>
        /// Initializes a new instance of the Book class with all necessary details.
        /// </summary>
        /// <param name="name">The title of the book.</param>
        /// <param name="dateAcquired">The date the book was acquired.</param>
        /// <param name="description">The description of the book.</param>
        /// <param name="author">The author of the book.</param>
        public Book(string name, DateTime dateAcquired, string description, string author)
            : base(name, dateAcquired, description)  // This correctly calls the base class constructor
        {
            Author = author;
        }

        /// <summary>
        /// Returns a formatted summary of the book's details.
        /// </summary>
        /// <returns>A string summary of the book.</returns>
        public override string GetSummary()
        {
            return $"\"{Name}\" by {Author}\nAcquired on: {DateAcquired:MM/dd/yyyy}\nDescription: {Description}";
        }
    }
}
