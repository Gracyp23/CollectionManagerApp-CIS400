﻿using System;
using System.Collections.Generic;
using System.IO;

namespace CollectionManagerApp
{
    public class CollectionDB
    {
        private string filePath;

        // Constructor - Sets the default file path
        public CollectionDB(string path = "collection.txt")
        {
            filePath = path;
        }

        // Method to Save Collection to File
        public void SaveCollection(List<CollectionItem> items)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (var item in items)
                    {
                        if (item is Book book)
                        {
                            // Saving item properties with a pipe (|) separator
                            writer.WriteLine($"{book.Name}|{book.DateAcquired}|{book.Description}|{book.Author}");
                        }
                    }
                }
                Console.WriteLine("Collection saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error saving collection: " + ex.Message);
            }
        }

        // Method to Load Collection from File
        public List<CollectionItem> LoadCollection()
        {
            List<CollectionItem> items = new List<CollectionItem>();

            try
            {
                // If file does not exist, return an empty list
                if (!File.Exists(filePath))
                    return items;

                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        var parts = line.Split('|');
                        if (parts.Length == 4) // This means it's a Book
                        {
                            // Parsing each part into a Book object
                            CollectionItem item = new Book(
                                parts[0],                                // Name
                                DateTime.Parse(parts[1]),                // DateAcquired
                                parts[2],                                // Description
                                parts[3]                                 // Author
                            );
                            items.Add(item);
                        }
                    }
                }
                Console.WriteLine("Collection loaded successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading collection: " + ex.Message);
            }

            return items;
        }
    }
}
