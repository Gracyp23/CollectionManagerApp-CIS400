
using System.Xml.Linq;

namespace CollectionManagerApp
{
    public partial class Form1 : Form
    {
        private IEnumerable<object> items;
        private object listViewCollection;

        public Form1()
        {
            InitializeComponent();
        }



        public partial class MyCollectionApp : Form
        {
            private List<CollectionItem> items = new List<CollectionItem>();
        }

        private void SaveCollectionToFile()
        {
            using (StreamWriter writer = new StreamWriter("collection.txt"))
            {
                foreach (var item in items)
                {

                }
            }
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Collect user inputs (You can replace these with your form inputs)
            string title = "Sample Title"; // Replace with actual user input
            string description = "Sample Description"; // Replace with actual user input
            string category = "Sample Category"; // Replace with actual user input

            MessageBox.Show("Item added to the collection!");

            // (Optional) Automatically save the collection after adding
            SaveCollectionToFile();

            MessageBox.Show("Item saved! (Functionality to be added later)");
            this.Close(); // Optional: closes the form after saving
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSaveCollection_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Item saved! (Functionality to be added later)");
            this.Close(); // Optional: closes the form after saving
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Open Collection File";
            openFileDialog.Filter = "Text Files (.txt)|.txt|All Files (.)|.";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Simulate file loading (you can add real functionality later)
                string filePath = openFileDialog.FileName;
                MessageBox.Show($"Opened file: {filePath}", "Open Collection");
            }
        }



        private void btnEdit_Click(object sender, EventArgs e)
        {
            AddEditForm addForm = new AddEditForm();
            addForm.ShowDialog(); // This shows the form as a popup
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
